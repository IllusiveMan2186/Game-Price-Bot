package com.gpb.email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpbEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
