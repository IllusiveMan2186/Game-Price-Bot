package com.gpb.email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpbEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpbEmailApplication.class, args);
	}

}
