package com.gpb.telegram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpbTelegramApplicationTests {

	@Test
	void contextLoads() {
	}

}
